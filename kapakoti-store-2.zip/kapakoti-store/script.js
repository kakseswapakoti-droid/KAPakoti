/* ==========================================================================
   KAPakoti — Core Script
   Handles: product catalog, cart, wishlist, nav, search, filters,
   quantity controls, forms, reveal animations, lazy loading.
   Pure vanilla JS. Cart/wishlist persist via localStorage so state
   survives navigation between pages (index.html + /pages/*.html).
   ========================================================================== */

(function () {
  "use strict";

  /* ------------------------------------------------------------------
     1. PRODUCT CATALOG
     Single source of truth used by home, shop, product, cart, checkout.
     Images are omitted (no real assets yet) — product-media divs render
     an SVG placeholder instead. Swap in <img> tags once photography
     is ready (see comments near .product-media in each page).
  ------------------------------------------------------------------ */
  const PRODUCTS = [
    { id: "kk-001", name: "Citadelle Bomber",   category: "Outerwear", collection: "Fondasyon", price: 428, compareAt: null, sizes: ["S","M","L","XL"], soldOut: [], tag: "New", desc: "A weighted bomber cut from Japanese nylon, quilted in a pattern drawn from the ramparts of the Citadelle Laferrière. Ribbed collar, brass hardware, interior map-pocket." },
    { id: "kk-002", name: "Cap-Haïtien Tee",     category: "Tops",      collection: "Fondasyon", price: 98,  compareAt: null, sizes: ["XS","S","M","L","XL"], soldOut: ["XS"], tag: null, desc: "Heavyweight 260gsm cotton, garment-dyed and stone-washed for a broken-in feel from day one. Puff-print coordinates on the left chest." },
    { id: "kk-003", name: "Anba Tonèl Cargo",    category: "Bottoms",   collection: "Lakou",     price: 268, compareAt: 320, sizes: ["28","30","32","34","36"], soldOut: [], tag: "Sale", desc: "Relaxed-taper cargo pant in brushed twill, six-pocket construction with articulated knees and a drawstring waist for movement." },
    { id: "kk-004", name: "Pòtoprens Coach Jacket", category: "Outerwear", collection: "Lakou",  price: 348, compareAt: null, sizes: ["S","M","L","XL"], soldOut: [], tag: null, desc: "Lightweight coach shell with a snap placket and taped seams. Embroidered stamp graphic on the back yoke." },
    { id: "kk-005", name: "Lakou Hoodie",        category: "Tops",      collection: "Lakou",     price: 188, compareAt: null, sizes: ["S","M","L","XL","XXL"], soldOut: [], tag: "New", desc: "Loopback fleece hoodie, double-layered hood, ribbed cuffs. Chain-stitched crest on the chest." },
    { id: "kk-006", name: "Rout Kwaze Denim",    category: "Bottoms",   collection: "Fondasyon", price: 238, compareAt: null, sizes: ["28","30","32","34","36","38"], soldOut: ["38"], tag: null, desc: "Straight-leg raw denim, 14oz selvedge, finished with a woven KAPakoti tab at the back pocket." },
    { id: "kk-007", name: "Basalt Cap",          category: "Accessories", collection: "Lakou",   price: 68,  compareAt: null, sizes: ["One Size"], soldOut: [], tag: null, desc: "Six-panel cap in brushed cotton twill with a curved brim and an embroidered stamp emblem." },
    { id: "kk-008", name: "Sitadèl Track Set",   category: "Sets",      collection: "Fondasyon", price: 398, compareAt: 460, sizes: ["S","M","L","XL"], soldOut: [], tag: "Sale", desc: "Matching track jacket and pant in a soft-hand tricot, taped side seams, half-zip mock neck." },
  ];

  const money = (n) => `$${n.toFixed(2)}`;

  /* SVG placeholders per category — swap for real photography later */
  const ICONS = {
    Outerwear: `<svg viewBox="0 0 100 100" fill="none" stroke-width="1.4"><path d="M30 15 H70 V30 H80 V50 H70 V90 H30 V50 H20 V30 H30 Z"/></svg>`,
    Tops: `<svg viewBox="0 0 100 100" fill="none" stroke-width="1.4"><path d="M35 20 L20 30 L25 42 L35 36 V85 H65 V36 L75 42 L80 30 L65 20 Q60 28 50 28 Q40 28 35 20 Z"/></svg>`,
    Bottoms: `<svg viewBox="0 0 100 100" fill="none" stroke-width="1.4"><path d="M32 15 H68 V25 L60 88 H52 L50 40 L48 88 H40 L32 25 Z"/></svg>`,
    Accessories: `<svg viewBox="0 0 100 100" fill="none" stroke-width="1.4"><rect x="25" y="18" width="50" height="16" rx="2"/><path d="M28 34 L22 90 H78 L72 34"/></svg>`,
    Sets: `<svg viewBox="0 0 100 100" fill="none" stroke-width="1.4"><path d="M50 12 L58 30 L78 33 L63 47 L67 67 L50 57 L33 67 L37 47 L22 33 L42 30 Z"/></svg>`,
  };
  const iconFor = (p) => ICONS[p.category] || ICONS.Tops;

  window.KAPAKOTI = { PRODUCTS, money, iconFor };

  /* ------------------------------------------------------------------
     2. STATE (cart + wishlist) — persisted to localStorage
  ------------------------------------------------------------------ */
  const STORAGE_KEY = "kapakoti_cart_v1";
  const WISHLIST_KEY = "kapakoti_wishlist_v1";

  function readStorage(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      return fallback;
    }
  }
  function writeStorage(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* storage unavailable — state stays in-memory for this page load */ }
  }

  let cart = readStorage(STORAGE_KEY, []); // [{id, size, qty}]
  let wishlist = readStorage(WISHLIST_KEY, []); // [id]

  function saveCart() { writeStorage(STORAGE_KEY, cart); renderCartDrawer(); updateCartBadge(); }
  function saveWishlist() { writeStorage(WISHLIST_KEY, wishlist); updateWishlistBadge(); }

  function addToCart(id, size, qty) {
    qty = qty || 1;
    const existing = cart.find((l) => l.id === id && l.size === size);
    if (existing) existing.qty += qty;
    else cart.push({ id, size, qty });
    saveCart();
    showToast(`Added to cart — ${PRODUCTS.find((p) => p.id === id)?.name || "Item"}`);
    openCartDrawer();
  }
  function removeFromCart(id, size) {
    cart = cart.filter((l) => !(l.id === id && l.size === size));
    saveCart();
  }
  function setQty(id, size, qty) {
    const line = cart.find((l) => l.id === id && l.size === size);
    if (!line) return;
    line.qty = Math.max(1, qty);
    saveCart();
  }
  function toggleWishlist(id) {
    const i = wishlist.indexOf(id);
    if (i > -1) wishlist.splice(i, 1); else wishlist.push(id);
    saveWishlist();
    document.querySelectorAll(`[data-wishlist-id="${id}"]`).forEach((btn) => btn.classList.toggle("active", wishlist.includes(id)));
  }
  function cartTotals() {
    const items = cart.map((l) => ({ ...l, product: PRODUCTS.find((p) => p.id === l.id) })).filter((l) => l.product);
    const subtotal = items.reduce((sum, l) => sum + l.product.price * l.qty, 0);
    const count = items.reduce((sum, l) => sum + l.qty, 0);
    return { items, subtotal, count };
  }

  window.KAPAKOTI.cart = { addToCart, removeFromCart, setQty, cartTotals, get raw() { return cart; } };
  window.KAPAKOTI.wishlist = { toggleWishlist, get raw() { return wishlist; } };

  /* ------------------------------------------------------------------
     3. NAV — scroll state, mobile menu, search overlay
  ------------------------------------------------------------------ */
  function initNav() {
    const header = document.querySelector(".site-header");
    if (header) {
      const onScroll = () => header.classList.toggle("solid", window.scrollY > 40);
      onScroll();
      window.addEventListener("scroll", onScroll, { passive: true });
    }

    const toggle = document.querySelector(".nav-toggle");
    const mobileNav = document.querySelector(".mobile-nav");
    if (toggle && mobileNav) {
      toggle.addEventListener("click", () => {
        const open = mobileNav.classList.toggle("open");
        toggle.setAttribute("aria-expanded", open ? "true" : "false");
        document.body.style.overflow = open ? "hidden" : "";
      });
      mobileNav.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => {
        mobileNav.classList.remove("open");
        document.body.style.overflow = "";
      }));
    }

    const searchTrigger = document.querySelector("[data-search-open]");
    const searchOverlay = document.querySelector(".search-overlay");
    const searchClose = document.querySelector(".search-close");
    const searchInput = document.querySelector(".search-box input");
    if (searchTrigger && searchOverlay) {
      searchTrigger.addEventListener("click", () => {
        searchOverlay.classList.add("open");
        setTimeout(() => searchInput && searchInput.focus(), 200);
      });
    }
    if (searchClose && searchOverlay) {
      searchClose.addEventListener("click", () => searchOverlay.classList.remove("open"));
    }
    if (searchOverlay) {
      searchOverlay.addEventListener("keydown", (e) => { if (e.key === "Escape") searchOverlay.classList.remove("open"); });
    }
    if (searchInput) {
      const resultsBox = document.querySelector(".search-results");
      searchInput.addEventListener("input", () => {
        const q = searchInput.value.trim().toLowerCase();
        if (!resultsBox) return;
        if (!q) { resultsBox.innerHTML = ""; return; }
        const matches = PRODUCTS.filter((p) => p.name.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
        resultsBox.innerHTML = matches.length
          ? matches.map((p) => `<a class="search-result" href="${pagePrefix()}product.html?id=${p.id}"><span>${p.name}</span><span>${money(p.price)}</span></a>`).join("")
          : `<div class="search-empty">No results for “${q}”.</div>`;
      });
    }

    updateCartBadge();
    updateWishlistBadge();
  }

  function pagePrefix() {
    // works whether we're at root (index.html) or inside /pages/
    return location.pathname.includes("/pages/") ? "" : "pages/";
  }

  function updateCartBadge() {
    const { count } = cartTotals();
    document.querySelectorAll("[data-cart-count]").forEach((el) => { el.textContent = count; el.setAttribute("data-count", count); });
  }
  function updateWishlistBadge() {
    document.querySelectorAll("[data-wishlist-count]").forEach((el) => { el.textContent = wishlist.length; el.setAttribute("data-count", wishlist.length); });
  }

  /* ------------------------------------------------------------------
     4. CART DRAWER
  ------------------------------------------------------------------ */
  function renderCartDrawer() {
    const list = document.querySelector(".cart-drawer-items");
    const subtotalEl = document.querySelector("[data-cart-subtotal]");
    if (!list) return;
    const { items, subtotal } = cartTotals();
    if (!items.length) {
      list.innerHTML = `<div class="cart-drawer-empty">Your cart is empty.<br><br><a class="btn btn-outline" href="${pagePrefix()}shop.html">Shop the collection</a></div>`;
    } else {
      list.innerHTML = items.map((l) => `
        <div class="cart-line">
          <div class="cart-line-img">${iconFor(l.product)}</div>
          <div class="cart-line-info">
            <div class="cart-line-name">${l.product.name}</div>
            <div class="cart-line-meta">Size ${l.size}</div>
            <div class="cart-line-row">
              <div class="qty-control">
                <button data-qty-dec data-id="${l.id}" data-size="${l.size}" aria-label="Decrease quantity">−</button>
                <span>${l.qty}</span>
                <button data-qty-inc data-id="${l.id}" data-size="${l.size}" aria-label="Increase quantity">+</button>
              </div>
              <span class="cart-line-price">${money(l.product.price * l.qty)}</span>
            </div>
            <button class="remove-line" data-remove-line data-id="${l.id}" data-size="${l.size}">Remove</button>
          </div>
        </div>`).join("");
    }
    if (subtotalEl) subtotalEl.textContent = money(subtotal);
    list.querySelectorAll("[data-qty-inc]").forEach((b) => b.addEventListener("click", () => {
      const line = cart.find((l) => l.id === b.dataset.id && l.size === b.dataset.size);
      setQty(b.dataset.id, b.dataset.size, (line?.qty || 1) + 1);
    }));
    list.querySelectorAll("[data-qty-dec]").forEach((b) => b.addEventListener("click", () => {
      const line = cart.find((l) => l.id === b.dataset.id && l.size === b.dataset.size);
      if (!line) return;
      if (line.qty <= 1) removeFromCart(b.dataset.id, b.dataset.size);
      else setQty(b.dataset.id, b.dataset.size, line.qty - 1);
    }));
    list.querySelectorAll("[data-remove-line]").forEach((b) => b.addEventListener("click", () => removeFromCart(b.dataset.id, b.dataset.size)));
  }

  function openCartDrawer() {
    document.querySelector(".cart-drawer")?.classList.add("open");
    document.querySelector(".cart-drawer-overlay")?.classList.add("open");
    document.body.style.overflow = "hidden";
  }
  function closeCartDrawer() {
    document.querySelector(".cart-drawer")?.classList.remove("open");
    document.querySelector(".cart-drawer-overlay")?.classList.remove("open");
    document.body.style.overflow = "";
  }
  function initCartDrawer() {
    document.querySelector("[data-cart-open]")?.addEventListener("click", (e) => { e.preventDefault(); openCartDrawer(); });
    document.querySelector("[data-cart-close]")?.addEventListener("click", closeCartDrawer);
    document.querySelector(".cart-drawer-overlay")?.addEventListener("click", closeCartDrawer);
    renderCartDrawer();
  }

  /* ------------------------------------------------------------------
     5. TOAST
  ------------------------------------------------------------------ */
  let toastTimer;
  function showToast(msg) {
    let toast = document.querySelector(".toast");
    if (!toast) {
      toast = document.createElement("div");
      toast.className = "toast";
      toast.innerHTML = `<span class="toast-dot"></span><span data-toast-msg></span>`;
      document.body.appendChild(toast);
    }
    toast.querySelector("[data-toast-msg]").textContent = msg;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
  }
  window.KAPAKOTI.showToast = showToast;

  /* ------------------------------------------------------------------
     6. PRODUCT CARD RENDERING (home featured + shop grid)
  ------------------------------------------------------------------ */
  function productCardHTML(p, prefix) {
    // prefix: path from the current page to product.html — "pages/" when called
    // from index.html at the site root, "" when called from within /pages/.
    prefix = prefix === undefined ? "pages/" : prefix;
    const inWishlist = wishlist.includes(p.id);
    return `
    <div class="product-card reveal" data-id="${p.id}" data-category="${p.category}" data-collection="${p.collection}" data-price="${p.price}">
      <a href="${prefix}product.html?id=${p.id}" class="product-media" data-lazy>
        ${p.tag ? `<span class="product-tag">${p.tag}</span>` : ""}
        ${iconFor(p)}
      </a>
      <button class="wishlist-btn ${inWishlist ? "active" : ""}" data-wishlist-id="${p.id}" aria-label="Add to wishlist" aria-pressed="${inWishlist}">
        <svg viewBox="0 0 24 24"><path d="M12 20s-7-4.4-9.5-8.6C.6 8 2 4.5 5.3 4c2-.3 3.7.7 4.7 2.3C11 4.7 12.7 3.7 14.7 4c3.3.5 4.7 4 3.8 7.4C16 15.6 12 20 12 20z"/></svg>
      </button>
      <button class="quick-add" data-quick-add="${p.id}">Add to cart</button>
      <a href="${prefix}product.html?id=${p.id}" class="product-info">
        <div class="product-name">${p.name}</div>
        <div class="product-cat">${p.category} · ${p.collection}</div>
        <div class="product-price">${p.compareAt ? `<span class="strike">${money(p.compareAt)}</span>` : ""}${money(p.price)}</div>
      </a>
    </div>`;
  }
  window.KAPAKOTI.productCardHTML = productCardHTML;

  function bindProductGridEvents(container) {
    container.querySelectorAll("[data-wishlist-id]").forEach((btn) => {
      btn.addEventListener("click", (e) => { e.preventDefault(); toggleWishlist(btn.dataset.wishlistId); });
    });
    container.querySelectorAll("[data-quick-add]").forEach((btn) => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        const p = PRODUCTS.find((x) => x.id === btn.dataset.quickAdd);
        if (p) addToCart(p.id, p.sizes.find((s) => !p.soldOut.includes(s)) || p.sizes[0], 1);
      });
    });
  }
  window.KAPAKOTI.bindProductGridEvents = bindProductGridEvents;

  /* ------------------------------------------------------------------
     7. NEWSLETTER / GENERIC FORM VALIDATION HELPERS
  ------------------------------------------------------------------ */
  function initNewsletterForms() {
    document.querySelectorAll("[data-newsletter-form]").forEach((form) => {
      form.addEventListener("submit", (e) => {
        e.preventDefault();
        const input = form.querySelector("input[type=email]");
        const msg = form.parentElement.querySelector(".form-msg") || form.querySelector(".form-msg");
        if (input && input.value.trim()) {
          if (msg) msg.textContent = "You're on the list — merci!";
          form.reset();
        }
      });
    });
  }

  /* ------------------------------------------------------------------
     8. REVEAL ON SCROLL + LAZY LOAD
  ------------------------------------------------------------------ */
  function initReveal() {
    const els = document.querySelectorAll(".reveal");
    if (!("IntersectionObserver" in window) || !els.length) { els.forEach((el) => el.classList.add("visible")); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.add("visible"); io.unobserve(entry.target); }
      });
    }, { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
  }
  window.KAPAKOTI.initReveal = initReveal;

  function initLazyMedia() {
    const els = document.querySelectorAll("[data-lazy]");
    if (!("IntersectionObserver" in window)) { els.forEach((el) => el.classList.remove("skeleton")); return; }
    const io = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.remove("skeleton"); io.unobserve(entry.target); }
      });
    }, { threshold: 0.05 });
    els.forEach((el) => { el.classList.add("skeleton"); io.observe(el); });
  }

  /* ------------------------------------------------------------------
     9. INIT
  ------------------------------------------------------------------ */
  document.addEventListener("DOMContentLoaded", () => {
    initNav();
    initCartDrawer();
    initNewsletterForms();
    initReveal();
    initLazyMedia();

    // smooth-scroll for in-page anchors
    document.querySelectorAll('a[href^="#"]').forEach((a) => {
      a.addEventListener("click", (e) => {
        const target = document.querySelector(a.getAttribute("href"));
        if (target) { e.preventDefault(); target.scrollIntoView({ behavior: "smooth" }); }
      });
    });

    // page-specific init hooks (defined in inline scripts per page)
    if (typeof window.KAPAKOTI_PAGE_INIT === "function") window.KAPAKOTI_PAGE_INIT();
  });
})();
